# v1.4.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin
1. [](#bugfix)    
    * Don't show unpublished pages in sitemap

# v1.3.0
## 02/25/2015

1. [](#new)
    * Added `ignores` list to allow certain routes to be left out of sitemap

# v1.2.0
## 11/30/2014

1. [](#new)
    * ChangeLog started...
