# v1.3.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.2.2
## 01/06/2015

1. [](#new)
    * Added a default `error.json.twig` file

# v1.2.1
## 11/30/2014

1. [](#new)
    * ChangeLog started...
