---
title: spectrum is green
slug: spectrum-is-green
date: 09/01/2015
taxonomy:
    category: blog
    tag: [thoughts, listen]
---

This is going to be a short and sweet update. I debated even writing an entry this week, but I like coming back here. I like having a task to do once a week and sticking to it.

===

Life has kept me busy. Today I have to pay rent, fix our dryer that the cat disconnected when she jumped behind it to explore, catch up on emails and text messages, and research various topics. I meant to work on music today, but that will have to wait for now.

I've worked on the 4th album for over four months. I wish I was further along in the process but I can accept what's been done so far. It's a process that takes time, and considering that I've written all these songs from scratch while recording instead of prepping for months beforehand, I'm progressing at a decent pace.

Anyway, here is a song that I like:

<style>.embed-container { position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; } .embed-container iframe, .embed-container object, .embed-container embed { position: absolute; top: 0; left: 0; width: 90%; height: 90%; }</style>
<iframe width="420" height="315" src="https://www.youtube-nocookie.com/embed/rsR40Skuxfo?rel=0" frameborder="0" allowfullscreen></iframe>

**-h**
