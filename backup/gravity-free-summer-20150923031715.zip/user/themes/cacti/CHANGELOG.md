# v1.2.0
## 08/25/2015

1. [](#new)
    * Added Polish translations
    * Added Norwegian translations
1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.1.1
## 07/21/2015

1. [](#bugfix)
    * Fixed issue with Retina profile image

# v1.1.0
## 07/19/2015

1. [](#new)
    * Added Greek translations
1. [](#improved)
    * Sets `<html lang="en">` dynamically based on language and/or default

# v1.0.1
## 07/14/2015

1. [](#improved)
    * Updated blueprints

# v1.0.0
## 07/13/2015

1. [](#new)
    * ChangeLog started...
