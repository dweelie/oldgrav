---
title: hello world
slug: hello-world
date: 07/19/2015
taxonomy:
    category: blog
    tag: [listen]
---

Hello, world. Welcome to the new **gravityfreesummer.com**!

===

I started this site in 2010, which isn't that long ago in human years but is a lifetime in internet years. Five years ago I posted my first blog entry, promising to someday make a better website. gfscom was originally hosted on tumblr and didn't get much love. It was rarely updated, filled with broken links, and felt a little pointless. I'm not sure if this new site design is necessarily "better" per se, but I like it. Also, I want this place to feel more alive. More updates. More thoughts. More music. More pictures. Just more of everything, a real place for this band.

But I don't want to just talk about the band. We're bombarded with enough ads on a daily basis. Simply posting entries about band news feels too much like I'm trying to sell something. I don't want to sell anything. This is free. You are free and hopefully I am too. Hopelessly hopeful.

**-h**

![](https://soundcloud.com/gravityfreesummer/ammna)
