# v1.2.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.1.6
## 06/16/2015

2. [](#new)
    * Try to create missing `backup` folder if it is missing

# v1.1.5
## 05/09/2015

2. [](#new)
    * Added check for `backup` folder for Grav > 0.9.27

# v1.1.4
## 04/26/2015

2. [](#new)
    * Changelog started

