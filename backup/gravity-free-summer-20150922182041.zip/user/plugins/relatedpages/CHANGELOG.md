# v0.1.0
## 09/11/2015

1. [](#improved)
    * Added blueprints for admin compatibility
   
# v1.0.3
## 12/04/2015

1. [](#new)
    * ChangeLog started...
