# v1.2.3
## 02/04/2015

1. [](#bugfix)
    * Update Plugin::mergeConfig() problem.

# v1.2.2
## 02/04/2015

1. [](#improved)
    * Update blueprints.yaml.

# v1.2.1
## 01/10/2015

1. [](#improved)
    * Add complete support for plugin configuration on Admin Plugin.

# v1.2.0
## 01/01/2015

1. [](#new)
    * Rewrite how to add jscomments to page/template. Now working with Twig function. Check the [README.md](README.md) for update.



# v1.1.2
## 12/31/2014

1. [](#bugfix)
    * Fix config typo.

# v1.1.1
## 12/23/2014

1. [](#bugfix)
    * Update the merge config with php function array_replace_recursive instead merge_array.

1. [](#new)
    * Added CHANGELOG.md with partial changelog update, I update in the next release.


# v1.1.0
## 12/06/2014

1. [](#bugfix)
    * Correct version number


# v1.0.9
## 12/05/2014

1. [](#improved)
    * Remove $page variable, not need.
    * Improve plugin events.
    * Update README.md with new configuration values.

1. [](#new)
    * Add methods for reading/writing/merge configuration with page header.


# v1.0.8
## 11/01/2014

1. [](#new)
    * Added Admin Plugin check.
    * Added demo link into the blueprints.yaml.


# v1.0.7
## 10/24/2014

1. [](#new)
    * Start changelog.
