<?php

error_reporting(E_ALL);
date_default_timezone_set(@date_default_timezone_get());
require_once __DIR__.'/../../vendor/autoload.php';
require_once __DIR__.'/Grav/TestCase.php';
